package com.abw.kamera_mantap

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
